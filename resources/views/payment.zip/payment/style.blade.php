<style>
    .shadow > .card-body {
        padding: 0 !important;
    }
    .select2-results__option:hover{
        background-color: #3875d7 !important; 
        color:white !important;
    }
</style>
<link rel="stylesheet" href="{{url('css/datepicker.css')}}" type="text/css" />
